import socket
import logging
from getpass import getpass
from hashlib import sha512
import csv
import threading

sock = socket.socket()

block = threading.Lock()

port = int(input("Port №: "))

def send_msg(sock, data):
        sock.send(data.encode())


def recv_msg(sock, q):
        return sock.recv(q).decode()


def hash_passwd(password):
        return sha512(bytes(password, 'utf-8')).hexdigest()
        


while True:
        try:
                sock.bind(('', port))
        except PermissionError:
                port+=1
                continue
        except OSError:
                port+=1
                continue
        break

sock.listen(0)
print(f"Port binded: {port}")


logging.basicConfig(filename='logs.log', filemode='a+', format='%(message)s', level=logging.INFO)

passwd_file = 'passwd_file'

clients = [] # Массив где храним адреса клиентов
print ('Start Server')

def process(conn, addr):
        global users, history, block

        try:
                with block:
                        with open("user_data.csv", 'a+', newline='') as file:
                                file.seek(0, 0)
                                reader = csv.reader(file, delimiter=';')
                                for row in reader:
                                        if row[0] == addr[0]:
                                                password = row[2]
                                                login = row[1]
                                                print(row)
                                                break
                                else:
                                        conn.send_msg("Input your name: ")
                                        login = conn.recv_msg(1024)
                                        conn.send_msg("Input your passwd: ")
                                        password = hash_passwd(conn.recv_msg(1024))
                                        writer = csv.writer(file, delimiter=';')
                                        writer.writerow([addr[0], login, password])
                        while True:
                                conn.send_msg("Confirm your password: ")
                                passwd = conn.recv_msg(1024)
                                if hash_passwd(passwd) == password:
                                        conn.send_msg((f"Hello {login}"))
                                        break
                                else:
                                        conn.send_msg("Incorrect password, try again")

        
        except:
                users.remove(conn)
                raise



def connecting():
        global users, CON_FLAG
        while True:
                if CON_FLAG:
                        conn, addr = sock.accept()
                        print(conn, addr)
                        logging.info(f"Connected: {addr}")
                        users.append(conn)
                        threading.Thread(target=process, args=(conn, addr), daemon=True).start()

def read_logs():
        global LOGGING
        LOGGING = True


def hide_logs():
        global LOGGING
        LOGGING = False



def clear_logs():
        with block:
                with open("logs.log", "w"):
                        pass



def pause():
        global CON_FLAG
        CON_FLAG = False


def resume():
        global CON_FLAG
        CON_FLAG = True


def clear_login():
        with block:
                with open("logins.csv", "w"):
                        pass

def menu():
        print(commands.keys())


commands = {'read_logs': read_logs, 'hide_logs': hide_logs, 'clear_login': clear_login,
                        'clear_logs': clear_logs, 'pause': pause, "menu": menu}

socket.socket.send_msg = send_msg
socket.socket.recv_msg = recv_msg

users = []
CON_FLAG = True
threading.Thread(target=connecting, daemon=True).start()


while True:
        text = input()
        if text == "exit":
                break
        if text in commands.keys():
                commands[text]()

