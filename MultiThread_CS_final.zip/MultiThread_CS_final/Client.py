import socket, threading

def send_msg(sock, data):
	sock.send(data.encode())


def receive_msg(sock, q):
	return sock.recv(q).decode()



def recv_f():
	while True:
		data = sock.receive_msg(1024)
		with t_block:
			print(data)

socket.socket.send_msg = send_msg
socket.socket.receive_msg = receive_msg

t_block = threading.Lock()
sock = socket.socket()
sock.setblocking(1)

port = int(input("Port №: "))
server = "localhost", port
print(f"Connecting by port number - ", port)
sock.connect(server)
print("Welcome to server!")

threading.Thread(target = recv_f, daemon = True).start() # thread.daemon = True - позволит основной
# программе выйти.

socket.socket.send_msg = send_msg
socket.socket.receive_msg = receive_msg


while True:
	msg = input("Message to server: ")
	sock.send_msg(msg)

	if msg == "exit":
		break

print("Disconnecting...")
sock.close()

